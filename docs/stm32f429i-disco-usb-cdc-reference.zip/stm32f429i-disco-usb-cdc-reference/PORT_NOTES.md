# STM32F429I-DISCO USB CDC reference

This is a board port of STMicroelectronics' STM32CubeF4 v1.28.3 example:

`Projects/STM324x9I_EVAL/Applications/USB_Device/CDC_Standalone`

The port retains ST's USB device stack and its OTG HS-in-FS initialization.
Only the board-specific configuration was changed:

- HSE is 8 MHz and `PLLM` is 8, producing 168 MHz SYSCLK and the required
  48 MHz USB clock through `PLLQ=7`.
- The build defines `USE_USB_HS` and `USE_USB_HS_IN_FS` so the OTG HS
  controller uses its embedded full-speed PHY.
- The ST example's PB12/PB14/PB15 AF12 and PB13 VBUS-input configuration is
  retained.
- The CDC-to-USART1 bridge is retained on PA9/PA10.
- Evaluation-board LED calls were removed because they are unrelated to USB.
- A standalone GNU Makefile was added for the devcontainer toolchain.

The working host identity is STMicroelectronics USB CDC ACM `0483:5740`. On
the tested Linux host it enumerated as `/dev/ttyACM1`; `/dev/ttyACM0` was
already occupied by the external USART adapter.

## Build

Obtain the official STM32CubeF4 v1.28.3 repository with its CMSIS Device and
STM32F4 HAL submodules. From this directory, run:

```sh
make CUBE_ROOT=/path/to/STM32CubeF4
```

The repository devcontainer contains `arm-none-eabi-gcc`. The build produces
the ELF, BIN, HEX, and map files under `build/`.

## Flash

The included BIN is linked for `0x08000000`. Flashing it replaces the Linux
bootloader sector until the Buildroot firmware is flashed again.

```sh
buildroot/output/host/bin/openocd \
  -f buildroot/output/host/share/openocd/scripts/board/stm32f429discovery.cfg \
  -c 'adapter speed 1000; init; reset halt; flash write_image erase path/to/stm32f429i-disco-usb-cdc.bin 0x08000000 bin; verify_image path/to/stm32f429i-disco-usb-cdc.bin 0x08000000 bin; reset run; shutdown'
```

The archived binaries were built with GNU Arm Embedded GCC 12.2.1. Their
SHA-256 checksums are recorded in `SHA256SUMS`.
